const imageInput = document.getElementById('imageInput');
const imageElement = document.getElementById('image');
const predictionElement = document.getElementById('prediction');

let model;

// Laadt het AI-model
async function loadModel() {
    model = await mobilenet.load();
    console.log("Model geladen!");
}

// Voorspel de inhoud van de afbeelding
async function predictImage() {
    const predictions = await model.classify(imageElement);
    predictionElement.innerHTML = `Voorspeld: <strong>${predictions[0].className}</strong> met ${Math.round(predictions[0].probability * 100)}% zekerheid`;
}

// Luistert naar veranderingen in het bestandinputveld
imageInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(event) {
            imageElement.src = event.target.result;
            imageElement.classList.remove("d-none");
            imageElement.onload = predictImage;
            predictionElement.innerHTML = "Bezig met analyseren...";
        };
        reader.readAsDataURL(file);
    }
});

loadModel();
