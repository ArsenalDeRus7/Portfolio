document.addEventListener("DOMContentLoaded", () => {
    const hook = document.getElementById("hook");
    const hookLine = document.getElementById("hookLine");
    const objectsContainer = document.getElementById("objectsContainer");
    const xpDisplay = document.getElementById("xp");
    const levelDisplay = document.getElementById("level");
    const indexBtn = document.getElementById("indexBtn");
    const fishBook = document.getElementById("fishBook");
    const closeBook = document.getElementById("closeBook");
    const pages = document.querySelectorAll(".page");
    let currentPage = 0;

    let hookPosition = window.innerWidth / 2;
    let hookSpeed = 2;
    let depth = 0;
    let moveLeft = false;
    let moveRight = false;
    let xp = 0; // Definieer XP
    let level = 1; // Definieer level
    let allFish = [
        { name: "Zalm", img: "media/zalm.png", rarity: 0.2 },
        { name: "Snoek", img: "media/snoek.png", rarity: 0.3 },
        { name: "Baars", img: "media/baars.png", rarity: 0.4 },
        { name: "Forel", img: "media/forel.png", rarity: 0.5 },
        { name: "Haring", img: "media/haring.png", rarity: 0.6 },
        { name: "Kabeljauw", img: "media/kabeljauw.png", rarity: 0.7 },
        { name: "Sardine", img: "media/sardine.png", rarity: 0.8 },
        { name: "Tonijn", img: "media/tonijn.png", rarity: 0.1 }, // Zeldzaam
        { name: "Makreel", img: "media/makreel.png", rarity: 0.3 },
        { name: "Paling", img: "media/paling.png", rarity: 0.4 },
        { name: "Steur", img: "media/steur.png", rarity: 0.05 } // Zeer zeldzaam
    ];

    let caughtFish = new Set(); // Hier komen de gevangen vissen
    let gameOverFlag = false; // Flag om aan te geven of het spel voorbij is

    // Haal verzamelde vissen op via AJAX
    function fetchCaughtFish() {
        fetch("duiken.php")
            .then(response => response.json())
            .then(data => {
                caughtFish = new Set(data);
                updateFishBook();
            });
    }

    function updateFishBook() {
        pages.forEach(page => page.innerHTML = ""); // Leegmaken

        allFish.forEach((fish, index) => {
            let fishEntry = document.createElement("div");
            fishEntry.classList.add("fishEntry");

            if (caughtFish.has(fish.name)) {
                let img = document.createElement("img");
                img.src = fish.img;
                fishEntry.appendChild(img);
            } else {
                fishEntry.textContent = "???"; // Onbekende vis
            }

            let pageIndex = Math.floor(index / 4);
            pages[pageIndex].appendChild(fishEntry);
        });
    }

    // Open visboek
    indexBtn.addEventListener("click", () => {
        fishBook.classList.remove("hidden"); // Maak het visboek zichtbaar
        fetchCaughtFish();  // Laad gevangen vissen wanneer het boek geopend wordt
    });

    // Sluit visboek
    closeBook.addEventListener("click", () => {
        fishBook.classList.add("hidden"); // Verberg het visboek
    });

    // Functie om een vis te kiezen op basis van zeldzaamheid
    function getRandomFish() {
        const rand = Math.random();
        let cumulativeRarity = 0;

        for (let i = 0; i < allFish.length; i++) {
            cumulativeRarity += allFish[i].rarity;
            if (rand < cumulativeRarity) {
                return allFish[i];
            }
        }

        // Als geen vis wordt geselecteerd (dit zou zelden moeten gebeuren), geef dan de eerste vis terug
        return allFish[0];
    }

    // Hook position update
    function updateHookPosition() {
        if (gameOverFlag) return; // Stop de haak als het spel voorbij is
        hookPosition = Math.max(0, Math.min(window.innerWidth - 50, hookPosition));
        hook.style.left = `${hookPosition}px`;
        hookLine.style.left = `${hookPosition + 25}px`;
    }

    function moveHookKeyboard(event) {
        if (gameOverFlag) return; // Stop het bewegen van de haak als het spel voorbij is
        if (event.key === "ArrowLeft") moveLeft = true;
        if (event.key === "ArrowRight") moveRight = true;
    }

    function stopHookKeyboard(event) {
        if (gameOverFlag) return; // Stop het bewegen van de haak als het spel voorbij is
        if (event.key === "ArrowLeft") moveLeft = false;
        if (event.key === "ArrowRight") moveRight = false;
    }

    function moveHookContinuously() {
        if (gameOverFlag) return; // Stop de haak als het spel voorbij is
        if (moveLeft) hookPosition -= 5;
        if (moveRight) hookPosition += 5;
        updateHookPosition();
    }

    function dropHook() {
        if (gameOverFlag) return; // Stop de haak als het spel voorbij is
        depth += hookSpeed;
        hook.style.top = `${depth}px`;
        hookLine.style.height = `${depth}px`;
        hookSpeed += 0.05;
        if (depth >= window.innerHeight) resetHook();
    }

    function resetHook() {
        depth = 0;
        hookSpeed = 2;
        hook.style.top = "0px";
        hookLine.style.height = "0px";
    }

    function spawnObjects() {
        const objectTypes = [
            { type: "fish", img: getRandomFish().img }, // Kies een willekeurige vis uit de lijst
            { type: "rock", img: "media/stone.png" },
            { type: "mine", img: "media/mine.png" }
        ];

        for (let i = 0; i < 10; i++) {  // Vergroot het aantal objecten
            const objData = objectTypes[Math.floor(Math.random() * objectTypes.length)];
            const object = document.createElement("img");
            object.src = objData.img;
            object.classList.add("object", objData.type);

            // Verander de grootte van sommige objecten
            let sizeMultiplier = 1;
            if (objData.type === "mine") {
                sizeMultiplier = 2; // Mijn is altijd 2x groter
            } else {
                sizeMultiplier = Math.random() < 0.2 ? 1.5 : 1; // 20% kans voor andere objecten groter te maken
            }

            object.style.transform = `scale(${sizeMultiplier})`;

            object.style.left = `${Math.random() * (window.innerWidth - 50)}px`;
            object.style.top = `${Math.random() * (window.innerHeight - 200) + 200}px`;
            objectsContainer.appendChild(object);
        }
    }

    function checkCollision(object, type) {
        const hookRect = hook.getBoundingClientRect();
        const objRect = object.getBoundingClientRect();

        // Controleer of de haak de vis raakt
        if (
            hookRect.left < objRect.right &&
            hookRect.right > objRect.left &&
            hookRect.bottom > objRect.top && // Zorg dat de haak de vis raakt in de verticale richting
            hookRect.top < objRect.bottom
        ) {
            object.remove();
            handleCatch(type, object);
        }
    }

    function updateXPDatabase() {
        fetch("duiken.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: `claim_xp=true`
        })
            .then(response => response.json())
            .then(data => {
                if (data.xp !== undefined && data.level !== undefined) {
                    xp = data.xp;
                    level = data.level;
                    xpDisplay.textContent = xp;
                    levelDisplay.textContent = level;
                }
            });
    }

    function handleCatch(type, object) {
        if (type === "fish") {
            let fishName = object.src.split("/").pop().split(".")[0]; // Haal de visnaam uit de afbeelding
            xp += 35; // 35 XP toevoegen
            saveFishToDB(fishName); // Bewaar de gevangen vis in de database
        } else if (type === "mine") {
            xp = Math.max(0, xp - 20);
            gameOver();
            return;
        } else if (type === "rock") {
            gameOver();
            return;
        }

        level = Math.floor(xp / 100) + 1; // Bereken level
        xpDisplay.textContent = xp;
        levelDisplay.textContent = level;

        updateXPDatabase(); // Stuur update naar database
    }

    function gameOver() {
        gameOverFlag = true; // Zet de flag naar true om het spel te stoppen
        const gameOverPopup = document.createElement("div");
        gameOverPopup.innerHTML = `
            <div style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
                        background: white; padding: 20px; text-align: center; border-radius: 10px;">
                <p>Volgende keer beter!</p>
                <button onclick="window.location.href='home.php'">Terug naar home</button>
                <button onclick="window.location.href='duiken.php'">Opnieuw proberen</button>
            </div>
        `;
        document.body.appendChild(gameOverPopup);
    }

    function saveFishToDB(fishName) {
        fetch("duiken.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: `fish_name=${fishName}`
        });
    }

    // Voeg touch-events toe voor mobiel
    let touchStartX = 0;

    function handleTouchStart(event) {
        if (gameOverFlag) return;
        touchStartX = event.touches[0].clientX;
    }

    function handleTouchMove(event) {
        if (gameOverFlag) return;
        const touchMoveX = event.touches[0].clientX;
        const deltaX = touchMoveX - touchStartX;

        // Verplaats de haak op basis van de swipe
        hookPosition += deltaX;
        hookPosition = Math.max(0, Math.min(window.innerWidth - 50, hookPosition)); // Zorg dat de haak binnen het scherm blijft
        updateHookPosition();

        touchStartX = touchMoveX; // Update de startpositie voor de volgende beweging
    }

    window.addEventListener("keydown", moveHookKeyboard);
    window.addEventListener("keyup", stopHookKeyboard);
    setInterval(moveHookContinuously, 30);
    setInterval(dropHook, 50);

    spawnObjects(); // Start spawning objects

    // Detecteer botsingen
    setInterval(() => {
        const objects = document.querySelectorAll(".object");
        objects.forEach((object) => {
            const objectType = object.classList.contains("fish") ? "fish" : object.classList.contains("mine") ? "mine" : "rock";
            checkCollision(object, objectType);
        });
    }, 50);

    // Voeg touch events toe voor mobiel
    window.addEventListener("touchstart", handleTouchStart);
    window.addEventListener("touchmove", handleTouchMove);
});
