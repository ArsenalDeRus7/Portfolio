<?php include('views/ai_view.php');
