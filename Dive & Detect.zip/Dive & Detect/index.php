<?php
include 'views/index_view.php';
?>