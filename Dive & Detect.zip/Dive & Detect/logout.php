<?php
session_start();

// Verwijder alle sessievariabelen
session_unset();

// Vernietig de sessie
session_destroy();

// Stuur de gebruiker door naar de inlogpagina met een succesmelding
header("Location: login.php?logout=success");
exit();
?>
