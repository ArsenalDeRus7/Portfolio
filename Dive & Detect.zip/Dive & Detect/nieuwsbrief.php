<?php
// Laadt de nieuwsbrief view
require "views/nieuwsbrief_view.php";
?>
