<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nieuwsbrief</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/nieuwsbrief.css">
    <link rel="stylesheet" href="public/footer.css">
</head>
<body>
<a href="home.php" class="logo-link">
    <img src="media/logo.png" alt="Logo" class="logo-img">
</a>

<div class="container">
    <h1>Nieuwsbrief</h1>
    <p>Blijf op de hoogte van het laatste nieuws!</p>

    <div class="news-item">
        <h3>Vis van de maand - Oktober</h3>
        <p>Deze maand in de spotlight: De tong! Lees er alles over in onze nieuwsbrief.</p>
        <img src="media/tong.jpg" alt="Vis van de maand">
    </div>

    <a href="ai.php" style="text-decoration: none">
    <div class="news-item">
        <h3>Nieuwe AI-update</h3>
        <p>Onze AI is nu slimmer dan ooit! Ontdek hoe het uw duikervaring kan verbeteren.</p>
        <img src="media/ai_home.jpg" alt="AI Update">
    </div>
    </a>

    <a href="duiken.php" style="text-decoration: none;">
    <div class="news-item">
        <h3>Speel de nieuwe duikgame!</h3>
        <p>Ga op een onderwateravontuur met onze nieuwste game.</p>
        <img src="media/game_nieuws.jpg" alt="Nieuwe duikgame">
    </div>
    </a>

    <button id="loadMore" class="btn-refresh mt-3">
        <i class="bi bi-arrow-clockwise"></i>
    </button>
</div>

<?php include "shared/footer.php"; ?>

<script src="js/nieuwsbrief.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
