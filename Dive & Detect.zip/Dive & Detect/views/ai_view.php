<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dive+Detect AI</title>

    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Externe CSS -->
    <link rel="stylesheet" href="css/ai.css">
    <link rel="stylesheet" href="public/footer.css">
    <script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs"></script>
    <script src="https://cdn.jsdelivr.net/npm/@tensorflow-models/mobilenet"></script>
</head>
<body>
<a href="home.php" class="logo-link">
    <img src="media/logo.png" alt="Logo" class="logo-img">
</a>

<div class="container">
    <h1>Dive+Detect AI</h1>
    <p>Upload een afbeelding van de zeebodem en laat het model de objecten herkennen.</p>
    <label class="custom-file-upload w-100" for="imageInput">
        <span>Klik om een afbeelding te kiezen of sleep het hierheen.</span>
        <input type="file" id="imageInput" class="d-none">
    </label>
    <img id="image" class="img-fluid d-none" alt="Afbeelding om te detecteren">
    <p id="prediction"></p>
    <a href="home.php" class="btn btn-custom mt-3">Terug naar home</a>
</div>
<?php include "shared/footer.php"; ?>
<script src="js/ai.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
