<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Aanmaken</title>
    <link rel="stylesheet" href="css/create.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="public/footer.css">
</head>
<body class="bg-dark text-white">
<a href="home.php" class="logo-link">
    <img src="media/logo.png" alt="Logo" class="logo-img">
</a>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card bg-secondary mt-5">
                <div class="card-body">
                    <h2 class="text-center text-primary">Maak een account aan</h2>
                    <?php if ($error): ?>
                        <div class="alert alert-danger">
                            <?php echo $error; ?>
                        </div>
                    <?php endif; ?>
                    <?php if ($success): ?>
                        <div class="alert alert-success">
                            <?php echo $success; ?>
                        </div>
                    <?php endif; ?>

                    <form action="create.php" method="POST">

                        <div class="mb-3">
                            <label for="first_name" class="form-label">Voornaam</label>
                            <input type="text" name="first_name" class="form-control" id="first_name" required>
                        </div>

                        <div class="mb-3">
                            <label for="last_name" class="form-label">Achternaam</label>
                            <input type="text" name="last_name" class="form-control" id="last_name" required>
                        </div>

                        <div class="mb-3">
                            <label for="username" class="form-label">Gebruikersnaam</label>
                            <input type="text" name="username" class="form-control" id="username" required>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" id="email" required>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label">Wachtwoord</label>
                            <input type="password" name="password" class="form-control" id="password" required>
                        </div>

                        <div class="mb-3">
                            <label for="country" class="form-label">Land</label>
                            <input type="text" name="country" class="form-control" id="country" required>
                        </div>

                        <div class="text-center">
                            <button type="submit" name="create" class="btn btn-primary">Account aanmaken</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'shared/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
