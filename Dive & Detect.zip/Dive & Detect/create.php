<?php
// Config bestand inladen voor databaseverbinding
include 'config.php';

$error = ''; // Foutmelding
$success = ''; // Succesbericht

// Controleren of het formulier is ingediend
if (isset($_POST['create'])) {
    // Verkrijg de formuliergegevens
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $email = trim($_POST['email']);
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $country = trim($_POST['country']);

    // Validatie: controleer of de velden niet leeg zijn
    if (empty($username) || empty($password) || empty($email) || empty($first_name) || empty($last_name) || empty($country)) {
        $error = "Alle velden zijn verplicht.";
    } else {
        // Wachtwoord hashen
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Controleer of de gebruiker al bestaat
        $query = "SELECT * FROM dive_detect_users WHERE username = :username OR email = :email";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['username' => $username, 'email' => $email]);
        $existing_user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existing_user) {
            $error = "Gebruikersnaam of e-mail is al in gebruik.";
        } else {
            // Voeg nieuwe gebruiker toe aan de database
            $query = "INSERT INTO dive_detect_users (username, password, email, first_name, last_name, country) 
                      VALUES (:username, :password, :email, :first_name, :last_name, :country)";
            $stmt = $pdo->prepare($query);

            $params = [
                'username' => $username,
                'password' => $hashed_password,
                'email' => $email,
                'first_name' => $first_name,
                'last_name' => $last_name,
                'country' => $country
            ];

            try {
                if ($stmt->execute($params)) {
                    $success = "Account succesvol aangemaakt! Je kunt nu inloggen.";
                    // Redirect naar de loginpagina
                    header("Location: login.php");
                    exit;
                } else {
                    $error = "Er is een probleem opgetreden. Probeer het later opnieuw.";
                }
            } catch (PDOException $e) {
                $error = "Fout bij het uitvoeren van de query: " . $e->getMessage();
            }
        }
    }
}

// Toon de view
include 'views/create_view.php';
?>
